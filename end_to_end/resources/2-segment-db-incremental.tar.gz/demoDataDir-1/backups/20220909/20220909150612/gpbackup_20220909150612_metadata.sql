
SET client_encoding = 'UTF8';


ALTER RESOURCE QUEUE pg_default WITH (ACTIVE_STATEMENTS=20);

ALTER RESOURCE GROUP admin_group SET CPU_RATE_LIMIT 1;

ALTER RESOURCE GROUP admin_group SET MEMORY_LIMIT 1;

ALTER RESOURCE GROUP default_group SET CPU_RATE_LIMIT 1;

ALTER RESOURCE GROUP default_group SET MEMORY_LIMIT 1;

ALTER RESOURCE GROUP default_group SET MEMORY_LIMIT 0;

ALTER RESOURCE GROUP default_group SET MEMORY_SHARED_QUOTA 80;

ALTER RESOURCE GROUP default_group SET MEMORY_SPILL_RATIO 0;

ALTER RESOURCE GROUP default_group SET CONCURRENCY 20;

ALTER RESOURCE GROUP default_group SET CPU_RATE_LIMIT 30;

ALTER RESOURCE GROUP admin_group SET MEMORY_LIMIT 10;

ALTER RESOURCE GROUP admin_group SET MEMORY_SHARED_QUOTA 80;

ALTER RESOURCE GROUP admin_group SET MEMORY_SPILL_RATIO 0;

ALTER RESOURCE GROUP admin_group SET CONCURRENCY 10;

ALTER RESOURCE GROUP admin_group SET CPU_RATE_LIMIT 10;

CREATE ROLE testrole;
ALTER ROLE testrole WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION RESOURCE QUEUE pg_default RESOURCE GROUP admin_group CREATEEXTTABLE (protocol='http') CREATEEXTTABLE (protocol='gpfdist', type='readable') CREATEEXTTABLE (protocol='gpfdist', type='writable');



CREATE DATABASE testdb TEMPLATE template0;

ALTER DATABASE testdb OWNER TO testrole;



COMMENT ON SCHEMA public IS 'standard public schema';


ALTER SCHEMA public OWNER TO testrole;


REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM testrole;
GRANT ALL ON SCHEMA public TO PUBLIC;
GRANT ALL ON SCHEMA public TO testrole;


CREATE SCHEMA schemaone;

ALTER SCHEMA schemaone OWNER TO testrole;


CREATE SCHEMA schematwo;

ALTER SCHEMA schematwo OWNER TO testrole;




CREATE TABLE schemaone.tableone (
	i integer
) DISTRIBUTED BY (i);


ALTER TABLE schemaone.tableone OWNER TO testrole;


CREATE TABLE schemaone.tabletwo (
	i integer
) DISTRIBUTED BY (i);


ALTER TABLE schemaone.tabletwo OWNER TO testrole;


CREATE TABLE schemaone.tablethree (
	i integer
) DISTRIBUTED BY (i);


ALTER TABLE schemaone.tablethree OWNER TO testrole;


CREATE TABLE schemaone.tablefour (
	i integer
) DISTRIBUTED BY (i);


ALTER TABLE schemaone.tablefour OWNER TO testrole;


CREATE TABLE schematwo.tableone (
	i integer
) DISTRIBUTED BY (i);


ALTER TABLE schematwo.tableone OWNER TO testrole;


CREATE TABLE schematwo.tabletwo (
	i integer
) DISTRIBUTED BY (i);


ALTER TABLE schematwo.tabletwo OWNER TO testrole;


CREATE TABLE schematwo.tablethree (
	i integer
) DISTRIBUTED BY (i);


ALTER TABLE schematwo.tablethree OWNER TO testrole;


CREATE TABLE schematwo.tablefour (
	i integer
) DISTRIBUTED BY (i);


ALTER TABLE schematwo.tablefour OWNER TO testrole;
