
SET client_encoding = 'UTF8';


ALTER RESOURCE QUEUE pg_default WITH (ACTIVE_STATEMENTS=20);

CREATE ROLE e2euser;
ALTER ROLE e2euser WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN PASSWORD 'md5d946b5e7943aa784c967b1f388b7d330' RESOURCE QUEUE pg_default CREATEEXTTABLE (protocol='http') CREATEEXTTABLE (protocol='gpfdist', type='readable') CREATEEXTTABLE (protocol='gpfdist', type='writable');                                                                                                        



CREATE DATABASE "corrupt-db" TEMPLATE template0;

ALTER DATABASE "corrupt-db" OWNER TO e2euser;



COMMENT ON SCHEMA public IS 'Standard public schema';


ALTER SCHEMA public OWNER TO e2euser;


REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM e2euser;
GRANT ALL ON SCHEMA public TO PUBLIC;
GRANT ALL ON SCHEMA public TO e2euser;




CREATE TABLE public.corrupt_table (
	i integer
) DISTRIBUTED BY (i);


ALTER TABLE public.corrupt_table OWNER TO e2euser;


CREATE TABLE public.good_table1 (
	i integer
) DISTRIBUTED BY (i);


ALTER TABLE public.good_table1 OWNER TO e2euser;


CREATE TABLE public.good_table2 (
	i integer
) DISTRIBUTED BY (i);


ALTER TABLE public.good_table2 OWNER TO e2euser;
